@echo off
setlocal enabledelayedexpansion
chcp 65001 >nul
title Inventor 本地桥 —— RC 飞行器总体设计器

cd /d "%~dp0"

echo ============================================================
echo   Inventor 本地桥
echo ============================================================
echo.
echo   作用：让网页上的「直接让 Inventor 建模」按钮能驱动 Inventor。
echo   安全：只在本机 127.0.0.1 上监听，数据不外传。
echo.
echo   启动后回到网页 →「Inventor 建模」标签 → 点「直接让 Inventor 建模」
echo   关闭本窗口 = 桥停止（网页其它功能不受影响）
echo.
echo ============================================================
echo.

where node >nul 2>nul
if errorlevel 1 (
    echo [错误] 没有找到 node（Node.js）
    echo.
    echo   本桥需要 Node.js 才能运行。
    echo   下载地址：https://nodejs.org/  （选 LTS 版本，一路下一步即可）
    echo.
    pause
    exit /b 1
)

for /f "tokens=*" %%v in ('node --version') do set NODEVER=%%v
echo 检测到 Node.js !NODEVER!
echo.

node inventor-bridge.js %1 %2
set EXITCODE=%errorlevel%

echo.
if not "%EXITCODE%"=="0" (
    echo [桥已退出，退出码 %EXITCODE%]
    echo   如果是「端口被占用」，可以换个端口重试：
    echo       启动Inventor桥.bat 8899
)
echo.
pause
