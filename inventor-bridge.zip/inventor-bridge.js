/*!
 * inventor-bridge.js —— 本地桥（让网页能一键驱动 Inventor 建模）
 *
 * 为什么需要它：
 *   浏览器无法启动或控制桌面程序，这是安全模型决定的，不是网站能绕过的。
 *   所以「网页直接操作 Inventor」必须有一个跑在本机的中间层：
 *   网页把参数 POST 给本桥，本桥通过 COM 调 Inventor 的 API 建模。
 *
 * 安全设计：
 *   · 只监听 127.0.0.1（外网访问不到）
 *   · 校验 Origin，只接受白名单来源（本站 Pages 地址 / file:// / 本地）
 *   · 不接收文件路径、不执行任意代码，只接受 JSON 参数
 *   · 任何数据都不外传，全部在本机
 *
 * 用法：
 *   node inventor-bridge.js          默认端口 8731
 *   node inventor-bridge.js 8899     指定端口
 *
 * 零依赖：只用 Node 内置模块。
 */
'use strict';

const http = require('http');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawn } = require('child_process');

const PORT = Number(process.argv[2]) || 8731;
const HOST = '127.0.0.1';

/* 允许的来源：站点 Pages 地址、本地文件、本机调试 */
const ALLOW_ORIGIN = [
  'https://albertina1119.github.io',
  'http://127.0.0.1:' + PORT,
  'http://localhost:' + PORT,
  'null'
];

function corsHeaders(origin) {
  const ok = !origin || ALLOW_ORIGIN.indexOf(origin) >= 0;
  return {
    'Access-Control-Allow-Origin': ok ? (origin || '*') : 'null',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
    // Chrome 私有网络访问（PNA）：HTTPS 页面调用 http://127.0.0.1 时需要，
    // 否则预检会被拦下，表现为「桥未连接」但桥其实开着。
    'Access-Control-Allow-Private-Network': 'true',
    'Access-Control-Max-Age': '600',
    'Content-Type': 'application/json; charset=utf-8'
  };
}

function send(res, code, obj, origin) {
  const body = JSON.stringify(obj, null, 2);
  res.writeHead(code, corsHeaders(origin));
  res.end(body);
}

/* ---------- Inventor 是否可用（通过 PowerShell 探测 COM）---------- */
function probeInventor() {
  return new Promise(function (resolve) {
    const ps = path.join(__dirname, 'probe_inventor.ps1');
    if (!fs.existsSync(ps)) {
      resolve({ available: false, reason: '缺少 probe_inventor.ps1' });
      return;
    }
    // 注意：spawn 在受限环境下会「同步抛出」EPERM（不只是发 error 事件），
    // 必须用 try/catch 兜住，否则一次探测就会把整个桥进程打挂。
    let child;
    try {
      child = spawn('powershell.exe', [
        '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass',
        '-File', ps
      ], { windowsHide: true, stdio: ['ignore', 'pipe', 'pipe'] });
    } catch (e) {
      resolve({ available: false, reason: 'PowerShell 无法启动：' + e.message });
      return;
    }

    let out = '', err = '';
    child.stdout.on('data', d => { out += d.toString(); });
    child.stderr.on('data', d => { err += d.toString(); });
    child.on('error', e => resolve({ available: false, reason: 'PowerShell 启动失败：' + e.message }));
    child.on('close', function () {
      const line = (out.split(/\r?\n/).filter(l => l.trim()).pop() || '').trim();
      if (/^OK/i.test(line)) {
        resolve({ available: true, detail: line.replace(/^OK\s*/, '') });
      } else {
        resolve({ available: false, reason: (line || err.trim() || '未检测到 Inventor').slice(0, 300) });
      }
    });
  });
}

/* ---------- 执行建模 ---------- */
let BUILDING = false;
function runBuild(params) {
  return new Promise(function (resolve) {
    if (BUILDING) { resolve({ ok: false, error: '上一次建模还在进行中，请稍候' }); return; }
    const ps = path.join(__dirname, 'inventor_build.ps1');
    if (!fs.existsSync(ps)) { resolve({ ok: false, error: '缺少 inventor_build.ps1' }); return; }

    const stamp = new Date().toISOString().replace(/[:.]/g, '-');
    const tmpDir = path.join(os.tmpdir(), 'dsh-inventor-' + stamp);
    try { fs.mkdirSync(tmpDir, { recursive: true }); } catch (e) {}
    const paramFile = path.join(tmpDir, 'params.json');
    const logFile = path.join(tmpDir, 'build.log');
    fs.writeFileSync(paramFile, JSON.stringify(params, null, 2), 'utf8');

    BUILDING = true;
    let child;
    try {
      child = spawn('powershell.exe', [
        '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass',
        '-File', ps, '-ParamFile', paramFile, '-LogFile', logFile
      ], { windowsHide: true, stdio: ['ignore', 'pipe', 'pipe'] });
    } catch (e) {
      BUILDING = false;
      resolve({
        ok: false,
        error: 'PowerShell 无法启动：' + e.message,
        log: '无法调用 PowerShell：' + e.message + '\n' +
          '请改用「下载 VBA 宏」路径（Inventor 里 Alt+F11 导入运行）。'
      });
      return;
    }

    let out = '', err = '';
    child.stdout.on('data', d => { out += d.toString(); });
    child.stderr.on('data', d => { err += d.toString(); });
    child.on('error', function (e) {
      BUILDING = false;
      resolve({ ok: false, error: 'PowerShell 启动失败：' + e.message });
    });
    child.on('close', function (code) {
      BUILDING = false;
      let log = '';
      try { log = fs.readFileSync(logFile, 'utf8'); } catch (e) {}
      const combined = (log + '\n' + out + '\n' + err).trim();
      resolve({
        ok: code === 0,
        exitCode: code,
        log: combined.slice(0, 8000),
        workDir: tmpDir
      });
    });
  });
}

/* ---------- HTTP ---------- */
const server = http.createServer(function (req, res) {
  const origin = req.headers.origin || '';
  if (req.method === 'OPTIONS') {
    res.writeHead(204, corsHeaders(origin));
    res.end();
    return;
  }

  const url = new URL(req.url, 'http://' + HOST + ':' + PORT);

  if (req.method === 'GET' && url.pathname === '/ping') {
    probeInventor().then(function (info) {
      send(res, 200, {
        ok: true,
        bridge: 'dsh-inventor-bridge',
        version: '1.0.0',
        port: PORT,
        building: BUILDING,
        inventor: info.available,
        detail: info.detail || '',
        reason: info.reason || ''
      }, origin);
    });
    return;
  }

  if (req.method === 'POST' && url.pathname === '/build') {
    const okOrigin = !origin || ALLOW_ORIGIN.indexOf(origin) >= 0;
    if (!okOrigin) {
      send(res, 403, { ok: false, error: '来源不被允许：' + origin }, origin);
      return;
    }
    let body = '';
    let tooBig = false;
    req.on('data', function (d) {
      body += d;
      if (body.length > 2 * 1024 * 1024) { tooBig = true; req.destroy(); }
    });
    req.on('end', function () {
      if (tooBig) { send(res, 413, { ok: false, error: '参数过大' }, origin); return; }
      let params = null;
      try { params = JSON.parse(body); } catch (e) {
        send(res, 400, { ok: false, error: 'JSON 解析失败：' + e.message }, origin);
        return;
      }
      if (!params || typeof params !== 'object') {
        send(res, 400, { ok: false, error: '参数为空' }, origin);
        return;
      }
      // 必需字段检查（不信任任何输入）
      const NEED = ['fullSpan', 'semiSpan', 'rootChord', 'tipChord', 'fuselageLength',
        'hStabSpan', 'hStabRootChord', 'vStabHeight', 'vStabRootChord'];
      const missing = NEED.filter(function (k) { return typeof params[k] !== 'number' || !isFinite(params[k]); });
      if (missing.length) {
        send(res, 400, { ok: false, error: '缺少或非法参数：' + missing.join(', ') }, origin);
        return;
      }
      runBuild(params).then(function (r) { send(res, r.ok ? 200 : 500, r, origin); });
    });
    return;
  }

  send(res, 404, { ok: false, error: '未知接口：' + req.method + ' ' + url.pathname }, origin);
});

server.on('error', function (e) {
  if (e.code === 'EADDRINUSE') {
    console.error('\n[错误] 端口 ' + PORT + ' 已被占用。');
    console.error('       可能桥已经在运行；或改用其它端口：node inventor-bridge.js 8899');
  } else {
    console.error('[错误] ' + e.message);
  }
  process.exit(1);
});

/* 进程级兜底：任何未捕获异常都不许把桥打死 —— 网页还在轮询 /ping，
   桥一崩用户看到的就是「连接失败」，比明确报错更难排查。 */
process.on('uncaughtException', function (e) {
  console.error('[桥内部错误，已忽略并继续运行] ' + (e && e.message ? e.message : e));
});
process.on('unhandledRejection', function (e) {
  console.error('[桥内部 Promise 拒绝，已忽略] ' + (e && e.message ? e.message : e));
});

server.listen(PORT, HOST, function () {
  console.log('');
  console.log('============================================================');
  console.log('  Inventor 本地桥已启动');
  console.log('============================================================');
  console.log('  监听地址：http://' + HOST + ':' + PORT);
  console.log('');
  console.log('  回到网页 →「Inventor 建模」标签 → 点「直接让 Inventor 建模」');
  console.log('');
  console.log('  本窗口关闭 = 桥停止（网页其它功能不受影响）');
  console.log('  所有数据只在本机流转，不上传任何地方');
  console.log('============================================================');
  console.log('');
});
