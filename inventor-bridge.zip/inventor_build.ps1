﻿# inventor_build.ps1 —— 用 Inventor COM API 按参数建 4 个零件
#
# 由 inventor-bridge.js 调用（也可单独手动运行）：
#   powershell -ExecutionPolicy Bypass -File inventor_build.ps1 -ParamFile params.json -LogFile build.log
#
# 输出：LogFile 记录每一步；退出码 0 表示全部成功，1 表示失败
# 说明：只建「外形 + 关键基准」，不含倒角 / 圆角 / 装配约束 / 舵面切割。

param(
    [Parameter(Mandatory = $true)][string]$ParamFile,
    [string]$LogFile = ''
)

$ErrorActionPreference = 'Stop'
$script:logLines = @()

function Log([string]$msg) {
    $line = (Get-Date -Format 'HH:mm:ss') + '  ' + $msg
    $script:logLines += $line
    Write-Output $msg
}

function SaveLog {
    if ($LogFile -and $LogFile.Trim() -ne '') {
        try { ($script:logLines -join "`r`n") | Set-Content -Path $LogFile -Encoding UTF8 } catch { }
    }
}

# ---- Inventor 常量（后期绑定，不依赖 interop 程序集）----
$kPartDocumentObject = 12290
$kJoinOperation = 61441

try {
    # ---------- 读参数 ----------
    if (-not (Test-Path $ParamFile)) { throw "参数文件不存在：$ParamFile" }
    $raw = Get-Content -Path $ParamFile -Raw -Encoding UTF8
    $p = $raw | ConvertFrom-Json
    Log ("读取参数：$($p.project) / 翼型 $($p.airfoilName)")

    $need = @('fullSpan', 'semiSpan', 'rootChord', 'tipChord', 'fuselageLength',
        'hStabSpan', 'hStabRootChord', 'vStabHeight', 'vStabRootChord')
    foreach ($k in $need) {
        if ($null -eq $p.$k) { throw "缺少参数：$k" }
    }

    # 翼型点（归一化）——若参数里没有，用一条 12% 厚度的近似对称翼型兜底
    $afx = @(); $afy = @()
    if ($p.airfoilPoints -and $p.airfoilPoints.Count -ge 8) {
        foreach ($pt in $p.airfoilPoints) { $afx += [double]$pt[0]; $afy += [double]$pt[1] }
    } else {
        for ($i = 0; $i -le 12; $i++) {
            $x = 0.5 * (1 - [Math]::Cos([Math]::PI * $i / 12))
            $yt = 0.6 * (0.2969 * [Math]::Sqrt($x) - 0.126 * $x - 0.3516 * $x * $x + 0.2843 * $x * $x * $x - 0.1015 * $x * $x * $x * $x)
            $afx += $x; $afy += $yt
        }
        for ($i = 12; $i -ge 1; $i--) {
            $x = 0.5 * (1 - [Math]::Cos([Math]::PI * $i / 12))
            $yt = 0.6 * (0.2969 * [Math]::Sqrt($x) - 0.126 * $x - 0.3516 * $x * $x + 0.2843 * $x * $x * $x - 0.1015 * $x * $x * $x * $x)
            $afx += $x; $afy += -$yt
        }
    }
    Log ("翼型点数：$($afx.Count)")

    # ---------- 连接 Inventor ----------
    $type = [Type]::GetTypeFromProgID('Inventor.Application')
    if ($null -eq $type) { throw '未注册 Inventor.Application，请确认已安装 Autodesk Inventor' }

    $inv = $null
    try {
        $inv = [System.Runtime.InteropServices.Marshal]::GetActiveObject('Inventor.Application')
        Log '已连接到正在运行的 Inventor'
    } catch {
        Log '没有已打开的 Inventor，正在启动…'
        try { $inv = [Activator]::CreateInstance($type) } catch { throw "启动 Inventor 失败：$($_.Exception.Message)" }
    }
    if ($null -eq $inv) { throw '无法获得 Inventor 实例' }
    try { $inv.Visible = $true } catch { }
    try { $inv.SilentOperation = $false } catch { }
    Log ("Inventor 版本：$($inv.SoftwareVersion)")

    $tg = $inv.TransientGeometry
    $template = $inv.FileManager.GetTemplateFile($kPartDocumentObject)

    function New-Part([string]$name) {
        $doc = $inv.Documents.Add($kPartDocumentObject, $template, $true)
        try { $doc.UnitsOfMeasure.LengthUnits = 11268 } catch { }   # kMillimeterLengthUnits
        try { $doc.DisplayName = $name } catch { }
        # 文件名也设一下，方便识别
        try {
            $ext = '.ipt'
            $target = Join-Path $env:TEMP ($name + '_' + (Get-Date -Format 'HHmmss') + $ext)
            $doc.SaveAs($target, $false)
        } catch { }
        return $doc
    }

    function New-AirfoilSketch($doc, $plane, [double]$chord, [double]$yOff, [double]$xOff, [double]$zOff) {
        $sk = $doc.ComponentDefinition.Sketches.Add($plane)
        $n = $afx.Count
        for ($i = 0; $i -lt $n - 1; $i++) {
            $x1 = $xOff + $afx[$i] * $chord
            $y1 = $yOff + $afy[$i] * $chord
            $x2 = $xOff + $afx[$i + 1] * $chord
            $y2 = $yOff + $afy[$i + 1] * $chord
            $sk.SketchLines.AddByTwoPoints($tg.CreatePoint2d($x1, $y1), $tg.CreatePoint2d($x2, $y2)) | Out-Null
        }
        $sk.SketchLines.AddByTwoPoints(
            $tg.CreatePoint2d($xOff + $afx[$n - 1] * $chord, $yOff + $afy[$n - 1] * $chord),
            $tg.CreatePoint2d($xOff + $afx[0] * $chord, $yOff + $afy[0] * $chord)) | Out-Null
        return $sk
    }

    function Add-Loft($doc, $sketchList) {
        $cd = $doc.ComponentDefinition
        $prof = $cd.Features.CreateProfile($cd.Sketches.CreateProfile, $kJoinOperation)
        foreach ($sk in $sketchList) {
            $prof.Add($sk.Profiles.Item(1)) | Out-Null
        }
        $loft = $cd.Features.LoftFeatures.Add($kJoinOperation, $prof)
        return $loft
    }

    # ---------- 1. 机翼 ----------
    Log '[1/4] 机翼…'
    $wing = New-Part 'Wing'
    $cdW = $wing.ComponentDefinition
    $yz = $cdW.WorkPlanes.Item(2)          # YZ 平面（对称面）
    try { $yz.Visible = $false } catch { }
    $skRoot = New-AirfoilSketch $wing $yz ([double]$p.rootChord) 0 0 0
    $tipPlane = $cdW.WorkPlanes.AddByPlaneAndOffset($yz, [double]$p.semiSpan)
    try { $tipPlane.Visible = $false } catch { }
    $dz = [double]$p.semiSpan * [Math]::Tan([double]$p.dihedral * [Math]::PI / 180)
    $dtip = [double]$p.semiSpan * [Math]::Tan([double]$p.sweep * [Math]::PI / 180)
    $skTip = New-AirfoilSketch $wing $tipPlane ([double]$p.tipChord) $dz $dtip 0
    Add-Loft $wing @($skRoot, $skTip) | Out-Null
    Log '      机翼放样完成'

    # ---------- 2. 机身 ----------
    Log '[2/4] 机身…'
    $fuse = New-Part 'Fuselage'
    $cdF = $fuse.ComponentDefinition
    $xz = $cdF.WorkPlanes.Item(3)          # XZ 平面
    try { $xz.Visible = $false } catch { }
    $bw = [double]$p.bodyMaxWidth
    $bh = [double]$p.bodyMaxHeight
    $fusLen = [double]$p.fuselageLength
    $noseLen = if ($null -ne $p.noseLength -and $p.noseLength -gt 0) { [double]$p.noseLength } else { $fusLen * 0.12 }
    $mountLen = if ($null -ne $p.wingMountLength -and $p.wingMountLength -gt 0) { [double]$p.wingMountLength } else { $fusLen * 0.13 }

    $sections = @(
        @{ off = 0; w = $bw * 0.30; h = $bh * 0.30 },
        @{ off = $noseLen; w = $bw; h = $bh },
        @{ off = [Math]::Min($fusLen - 1, $noseLen + $mountLen); w = $bw; h = $bh },
        @{ off = $fusLen; w = $bw * 0.28; h = $bh * 0.34 }
    )
    $fuseSk = @()
    foreach ($s in $sections) {
        if ($s.off -le 0) { $pl = $xz }
        else { $pl = $cdF.WorkPlanes.AddByPlaneAndOffset($xz, $s.off) }
        try { $pl.Visible = $false } catch { }
        $sk = $cdF.Sketches.Add($pl)
        $a = $s.w / 2; $b = $s.h / 2
        $sk.SketchLines.AddAsTwoPointRectangle($tg.CreatePoint2d(-$a, -$b), $tg.CreatePoint2d($a, $b)) | Out-Null
        $fuseSk += $sk
    }
    Add-Loft $fuse $fuseSk | Out-Null
    Log '      机身放样完成'

    # ---------- 3. 平尾 ----------
    Log '[3/4] 平尾…'
    $hst = New-Part 'HStab'
    $cdH = $hst.ComponentDefinition
    $hPlane = $cdH.WorkPlanes.Item(2)
    try { $hPlane.Visible = $false } catch { }
    $h1 = New-AirfoilSketch $hst $hPlane ([double]$p.hStabRootChord) 0 0 0
    $hPlane2 = $cdH.WorkPlanes.AddByPlaneAndOffset($hPlane, [double]$p.hStabSpan / 2.0)
    try { $hPlane2.Visible = $false } catch { }
    $h2 = New-AirfoilSketch $hst $hPlane2 ([double]$p.hStabTipChord) 0 0 0
    Add-Loft $hst @($h1, $h2) | Out-Null
    Log '      平尾放样完成'

    # ---------- 4. 垂尾 ----------
    Log '[4/4] 垂尾…'
    $vst = New-Part 'VStab'
    $cdV = $vst.ComponentDefinition
    $vPlane = $cdV.WorkPlanes.Item(2)
    try { $vPlane.Visible = $false } catch { }
    $v1 = New-AirfoilSketch $vst $vPlane ([double]$p.vStabRootChord) 0 0 0
    $vPlane2 = $cdV.WorkPlanes.AddByPlaneAndOffset($vPlane, [double]$p.vStabHeight)
    try { $vPlane2.Visible = $false } catch { }
    $vSweep = if ($null -ne $p.vStabSweep) { [double]$p.vStabSweep } else { 5 }
    $vdz = [double]$p.vStabHeight * [Math]::Tan($vSweep * [Math]::PI / 180)
    $v2 = New-AirfoilSketch $vst $vPlane2 ([double]$p.vStabTipChord) 0 $vdz 0
    Add-Loft $vst @($v1, $v2) | Out-Null
    Log '      垂尾放样完成'

    Log ''
    Log '全部 4 个零件已生成：Wing / Fuselage / HStab / VStab'
    Log '下一步：新建装配 → 依次装入 4 个零件 → 按建模参数表定位。'
    SaveLog
    exit 0
} catch {
    Log ('失败：' + $_.Exception.Message)
    if ($_.ScriptStackTrace) { Log ('堆栈：' + $_.ScriptStackTrace) }
    SaveLog
    exit 1
}
