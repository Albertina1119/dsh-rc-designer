Inventor 本地桥 —— 让网页能一键驱动 Inventor 建模
======================================================================

【为什么需要这个文件夹】

浏览器出于安全限制，无法启动或控制桌面程序。Inventor 是 Windows
桌面应用，所以「网页直接操作 Inventor」必须有一个跑在本机的中间层。
这个文件夹就是那个中间层，不到 30 KB，只用 Node.js 内置模块，零依赖。

【怎么用】

1. 先装 Node.js（只需一次）
   https://nodejs.org/  → 选 LTS 版本 → 一路「下一步」

2. 双击本文件夹里的「启动Inventor桥.bat」
   会弹出一个黑窗口，显示：
       Inventor 本地桥已启动
       监听地址：http://127.0.0.1:8731

3. 不要关这个窗口。回到网页：
   https://albertina1119.github.io/dsh-rc-designer/
   → 结果页 →「Inventor 建模」标签
   → 点「直接让 Inventor 建模」

4. Inventor 会自动打开（或连上已打开的实例），几秒后生成 4 个零件：
   Wing / Fuselage / HStab / VStab

5. 用完后关掉那个黑窗口即可。

【文件说明】

  inventor-bridge.js     本地 HTTP 服务（端口 8731）
  inventor_build.ps1     用 Inventor COM API 建模的脚本
  probe_inventor.ps1     探测是否装了 Inventor（只读，不改东西）
  启动Inventor桥.bat      一键启动（带 Node.js 检测）

【安全说明】

· 只监听 127.0.0.1，外网访问不到
· 校验 Origin，只接受本站 / 本地 / file:// 来源
· 不接收文件路径、不执行任意代码，只收 JSON 数字参数
· 所有数据只在本机流转，不上传任何服务器
· 关掉窗口即停止

【如果失败】

问题：点按钮提示「桥未连接」
  → 确认黑窗口还开着，且显示「已启动」
  → 检查端口：浏览器访问 http://127.0.0.1:8731/ping 应返回 JSON

问题：提示「未注册 Inventor.Application」
  → 说明这台机器没装 Inventor，或装的是别的 CAD
  → 这种情况请用「下载 VBA 宏」那条路（在有 Inventor 的机器上导入运行）

问题：草图或放样报错
  → Inventor 各版本 API 有细微差异。VBA 宏那条路更稳（在 Inventor
    自己的 VBA 环境里跑，不需要外部脚本），建议优先用宏。

问题：端口被占用
  → 启动Inventor桥.bat 8899

【两条路的区别】

  路径 A：下载 VBA 宏 → Inventor 里 Alt+F11 导入 → F5 运行
          · 零安装，最稳，推荐先用
          · 需要手动点两下

  路径 B：启动本桥 → 网页点按钮
          · 真正一键
          · 需要装 Node.js 并保持窗口开着

两条路生成的模型完全一致（同一套参数、同一套几何逻辑）。
