﻿# probe_inventor.ps1 —— 探测本机是否装了 Inventor（只读，不改任何东西）
# 成功输出： OK <版本说明>
# 失败输出： NO <原因>
$ErrorActionPreference = 'Stop'

try {
    $type = [Type]::GetTypeFromProgID('Inventor.Application')
    if ($null -eq $type) {
        Write-Output 'NO 未注册 Inventor.Application（可能没安装 Inventor）'
        exit 0
    }
    $inv = $null
    try {
        # 先尝试连已打开的实例（不启动新实例）
        $inv = [System.Runtime.InteropServices.Marshal]::GetActiveObject('Inventor.Application')
    } catch {
        # 没有已打开的实例，就用类工厂创建一个（会启动 Inventor）
        $inv = [Activator]::CreateInstance($type)
    }
    if ($null -eq $inv) {
        Write-Output 'NO 无法创建 Inventor 实例'
        exit 0
    }
    $ver = $inv.SoftwareVersion
    $disp = ''
    try { $disp = $inv.Caption } catch { }
    Write-Output ("OK " + $ver + " | " + $disp)
    # 注意：不主动退出 Inventor，用户可能正在用
} catch {
    Write-Output ('NO ' + $_.Exception.Message)
}
